/*
* Copyright (c) 2005 Nokia Corporation and/or its subsidiary(-ies). 
* All rights reserved.
* This component and the accompanying materials are made available
* under the terms of the License "Symbian Foundation License v1.0"
* which accompanies this distribution, and is available
* at the URL "http://www.symbianfoundation.org/legal/sfl-v10.html".
*
* Initial Contributors:
* Nokia Corporation - initial contribution.
*
* Contributors:
*
* Description:  CRfsExamplePlugin from RfsExamplePlugin.cpp
*
*/


// INCLUDE FILES
#include "RfsExamplePlugin.h"

// LOCAL CONSTANTS
_LIT(KScriptPath, "");

// ================= MEMBER FUNCTIONS =======================

// C++ default constructor can NOT contain any code, that
// might leave.
//
CRfsExamplePlugin::CRfsExamplePlugin()
    {
    }

CRfsExamplePlugin::CRfsExamplePlugin(TAny* /*aInitParams*/)
    {
    }

// Destructor
CRfsExamplePlugin::~CRfsExamplePlugin()
    {
    }

// ---------------------------------------------------------
// NewL
// ---------------------------------------------------------
//
CRfsExamplePlugin* CRfsExamplePlugin::NewL(TAny* aInitParams)
    {
    #ifdef _DEBUG
        RDebug::Print(_L("CRfsExamplePlugin::NewL()"));
    #endif
    CRfsExamplePlugin* self = new (ELeave) CRfsExamplePlugin(aInitParams);
    CleanupStack::PushL(self);
    self->ConstructL();
    CleanupStack::Pop();
    return self;
    }


// ---------------------------------------------------------
// ConstructL
// ---------------------------------------------------------
//
void CRfsExamplePlugin::ConstructL()
    {
    #ifdef _DEBUG
        RDebug::Print(_L("CRfsExamplePlugin::ConstructL()"));
    #endif
    }

void CRfsExamplePlugin::RestoreFactorySettingsL( const TRfsReason aType )
    {
    #ifdef _DEBUG
        RDebug::Print(_L("CRfsExamplePlugin::RestoreFactorySettingsL(%d)"), aType);
    #endif
    }

void CRfsExamplePlugin::GetScriptL( const TRfsReason /*aType*/, TDes& aPath )
    {
    aPath.Copy( KScriptPath);
    }

void CRfsExamplePlugin::ExecuteCustomCommandL( const TRfsReason /*aType*/,
                                        TDesC& /*aCommand*/ )
    {
    }

// End of file
